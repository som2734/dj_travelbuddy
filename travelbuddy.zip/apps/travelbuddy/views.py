from django.shortcuts import render, HttpResponse, redirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from .models import Users, Trips
from django.contrib.auth import logout
import bcrypt
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

def index(request):
    return render(request, 'travelbuddy/index.html')

def register(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        conf_password = request.POST['conf_password']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        b_day=request.POST['b_day']
        print email
        errors = Users.objects.validation(email, password, conf_password, first_name, last_name, b_day)
        if errors:
            for error in errors:
                messages.error(request, error)
            return redirect('/')
        else:
            print ('should be creating a user now...')
            pw_hash=bcrypt.hashpw(password.encode(), bcrypt.gensalt())
            Users.objects.create(email=email, pw_hash=pw_hash, first_name=first_name, last_name=last_name, b_day=b_day)
            messages.success(request, 'You have registered successfully!')
            return redirect('/')

def login(request):
    if request.method == "POST":
        print ('should be logging in now....')
        email = request.POST['email']
        password = request.POST['password']
        print ('Login credentials entered')
        result = Users.objects.login(email, password)
        if type(result) == list:
            print ('returned result is not object')
            for error in result:
                messages.error(request, error)
            return redirect('/')
        else:
            print "we should be successful..."
            request.session['logged_user'] = result.id
            return redirect('/profile')

def profile(request):
    userid = Users.objects.get(id=request.session['logged_user'])
    messages.success(request, 'Welcome, {}!'.format(userid.first_name))
    print userid.first_name
    mytrip = Trips.objects.filter(user=userid)
    other_trip = Trips.objects.all()
    context={'id':userid, 'mytrips':mytrip, 'all_trips':other_trip}
    print other_trip
    return render(request, 'travelbuddy/profile.html', context)

def log_out(request):
    current_user = Users.objects.get(id=request.session['logged_user'])
    logout(request)
    return redirect('/')

def add_trip(request):
    return render(request, 'travelbuddy/add_trip.html')

def process_trip(request):
    userid = Users.objects.get(id=request.session['logged_user'])
    if request.method == "POST":
        destination = request.POST['destination']
        plan = request.POST['plan']
        start_date = request.POST['start_date']
        end_date = request.POST['end_date']
        new_trip = Trips.objects.create(user=userid, destination=destination, plan=plan, start_date=start_date, end_date=end_date)

    return redirect('/profile')

def trip_details(request, id):
    trip = Trips.objects.filter(id=id)
    print trip
    return render(request, 'travelbuddy/trip_details.html')


# Create your views here.
